export const helloModel= () =>{
    console.log('Export done by the model');
}