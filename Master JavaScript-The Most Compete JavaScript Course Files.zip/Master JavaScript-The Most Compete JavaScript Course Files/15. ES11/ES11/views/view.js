export const helloView = () =>{
    console.log('Export done by the view');
}