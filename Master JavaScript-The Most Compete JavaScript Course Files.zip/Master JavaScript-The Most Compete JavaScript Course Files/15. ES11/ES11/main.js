const model = './models/Model.js';

import(model).then((module)=>{
    module.helloModel();
});

async function load(){
    let getViewData = await import('./views/view.js');
    getViewData.helloView();
}
load();