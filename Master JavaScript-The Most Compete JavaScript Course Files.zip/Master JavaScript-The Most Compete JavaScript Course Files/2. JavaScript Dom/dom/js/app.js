var doc, form, links,length;

doc = document;
//will give us document html collection
doc = document.all;
// doc = document.all[0];//zero position is the head
//doc = document.all[10];//zero position is the title

length = document.all.length;//this will give you total number of elements in the document
doc = document.domain;
doc = document.URL;
doc = document.characterSet;
doc = document.doctype;

//links

links = document.links;//this will return collection of links

links = document.links[4];//this will return btn-reset link
links = document.links[4].className;//this will return btn-reset class name
links = document.links[4].classList;//this will return dom token list
links = document.links[4].classList[0];


//html forms

form = document.forms;
form = document.forms[1];
form = document.forms[1].method;




//result
console.log(doc);
console.log(length);
console.log(links);
console.log(form);