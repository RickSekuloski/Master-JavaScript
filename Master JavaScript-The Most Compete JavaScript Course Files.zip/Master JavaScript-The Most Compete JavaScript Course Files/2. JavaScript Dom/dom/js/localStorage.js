/*
Method                  Description
1.setItem()      Add key and value to local storage   
2.getItem()      Retrieve a value by the key   
3.removeItem()   Remove an item by key
4.clear()        Clear all storage   

*/

//1.setItem() 
//localStorage.setItem('my-key','my-value');

// //2.getItem() 
// var item = localStorage.getItem('my-key');
// // alert(item);
// //console.log(item);

// //3.removeItem() 
// localStorage.removeItem('my-key');

// //4. clear() 
// localStorage.clear();

//Session Storage

//  sessionStorage.setItem('my-key','my-sessionValue');



// const form = document.querySelector('form');
// const ul = document.querySelector('ul');
// const button = document.querySelector('.btn-reset');
// const input = document.querySelector('item');
// console.log(form,ul,button,input);

//create an html element
// const heading = document.createElement('h1');
// //add class to heading element
// heading.className = 'heading-one';
// //add id to heading element
// heading.id = 'heading';
// //add elements inside an element
// // heading.innerHTML = '<span>Here is the span inside the h1</span>';

// heading.textContent = 'This is the new heading from JS';

// const card = document.querySelector('.card-body');
// //this will place the heading into the card body
// card.appendChild(heading);

// console.log(heading);

