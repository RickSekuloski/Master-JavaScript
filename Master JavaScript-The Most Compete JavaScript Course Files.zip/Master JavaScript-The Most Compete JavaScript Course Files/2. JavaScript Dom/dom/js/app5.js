var formBtn,cardBody,cardTitle,formBtnReset;

formBtn = document.querySelector('#add');
cardBody = document.querySelector('.card-body');
cardTitle = document.querySelector('.card-title');
formBtnReset = document.querySelector('.btn-reset');

//Click
//Old Click with function
// formBtn.addEventListener('click',function(e){

//     console.log(e.type);
//     e.preventDefault();
// });

//Click without unamed function
formBtn.addEventListener('click',eventTracker);
//Double Click
formBtn.addEventListener('dblclick',eventTracker);

//Mouse Click
formBtnReset.addEventListener('mousedown',eventTracker);

//Mouse Click
formBtnReset.addEventListener('mouseup',eventTracker);
//Mouse Enter
cardBody.addEventListener('mouseenter',eventTracker);
//Mouse Leave
cardBody.addEventListener('mouseleave',eventTracker);
//Mouse Leave
cardBody.addEventListener('mousemove',eventTracker);


//DRY don't repeat yourself - don't repeat the code
function eventTracker(e){
    
        console.log(e.type);
        e.preventDefault();
}