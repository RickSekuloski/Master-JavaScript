//ES10 Exercises:

/* 1 Turn this array into a new array flat array
  const array = [[1],[2],[3],[[[4]]],[[[5]]]]
*/

//Solution:
console.log(array.flat(3))


/* #2 Turn this array into a new array: 
[ 'Hello young fella!', 'you are great and', ' you are learning new features!' ]
*/
const greeting = [["Hello", "young", "fella!"], ["you", "are","great", "and"], ["you", "are","learning", "new","features"]];

//Solution:
console.log(greeting.flatMap(curr => curr.join(' ')))


/*#3 Turn the greeting array above into a string:
Hello young fella! you are great and you are learning new features!
*///Solution
console.log(greeting.flatMap(curr => curr.join(' ')).join(' '))

/*#4 Turn the trapped 10 number into: [10] an array of one element */
const escape = [[[[[[[[[[[[[[[[[[[[[[[[[[10]]]]]]]]]]]]]]]]]]]]]]]]]];
//Solution
console.log(escape.flat(Infinity))

/* Hint: Infintiy It represents the maximum amount of memory that we can hold for a number! 
Learn more here: https://riptutorial.com/javascript/example/2337/infinity-and--infinity*/

/* 5 Single line answer, clean the email from start and end white space'*/
const userEmail = '     whatShouldIUse@gmail.com   '
//Solution:
console.log(userEmail.trimEnd().trimStart())


/* 6 Turn the below users (key value pairs, key is the username and value is their ID number) 
into an array: [ [ 'user1', 1624 ], [ 'user2', 3384 ], [ 'user3', 10565 ] ]*/
const users = { user1: 1624, user2: 3384, user3: 10565 }

//Solution
const cleanData = Object.entries(users);
console.log(cleanData);

/* 7 Create an array where user ID is multiplied by two
 -- Should output:[ [ 'user1', 3248 ], [ 'user2', 6768 ], [ 'user3', 21130 ] ]
 */
//Solution
newArray = cleanData.map((user) => [user[0], user[1] * 2])

/* 8 Ok last, make an obj from the last output
Expected output: Object { user1: 3248, user2: 6768, user3: 21130 }*/

//Solution
const arrayObj = Object.fromEntries(newArray)
console.log(arrayObj)