/* ES10 - ECMAScript 2019 

1. .flat()
2. .flatMap()
3. trimStart()
4. trimEnd()
5.Object.fromEntries();
6. try {

}
catch{

}
*/

const array =[1,2,3,4,5];
array.flat();
const array1 = [1,[2,3], 4, [5,6]];
array1.flat();

const array2 = [1,[2,3], 4, [5,[6]]];
array2.flat(2);
const animals = [['🐍','🦎'],'🦑','🦐','🦀',['🦈','🐟'],[[['🦖','🐲']]],['🦏','🦄']];
animals.flat(20);

const data = ['rick','andy','tom',,,,,'diego','jason','','chuck norris'];
data.flat();

const animalsReleased = animals.flatMap(animal => animal +'Free!');

const userName = '         Rick';
const lastName = 'Sekuloski    ';

console.log(userName.trimStart());
console.log(lastName.trimEnd());

const userNames = [['Andy Murray',23],  ['Tom Hardy',45], ['Morgan Freeman',72]];

Object.fromEntries(userNames);

const obj = userNames1 = [['Andy Murray',23],  ['Tom Hardy',45], ['Morgan Freeman',72]];
Object.fromEntries(obj);
Object.entries(obj);

try{
    throw Error;
 "Morgan" + ' Freeman';
}
catch{
    console.log("error ");
}