//AJAX CALLS WITH FETCH AND PROMISE
//fetch('https://jsonplaceholder.typicode.com/users');
//FETCH WILL RETURN A PROMISE

//CONSUME THE PROMISE WITH THEN AND CATCH
fetch('https://jsonplaceholder.typicode.com/users')
.then(result =>{
    console.log(result);
    //the json will return a promise
    return result.json();
})
.then(data =>{
    // console.log(data);
    const user = data[0];
   // console.log(user);
    const name = user.name;
    const userName = user.username;
    const email = user.email;
    const street = user.address.street;
    const city = user.address.city;
    const work = user.company.name;
    console.log(`${name}, ${userName}, ${email},
    ${street}, ${city}, ${work}`);
})
.catch(error =>console.log(error));