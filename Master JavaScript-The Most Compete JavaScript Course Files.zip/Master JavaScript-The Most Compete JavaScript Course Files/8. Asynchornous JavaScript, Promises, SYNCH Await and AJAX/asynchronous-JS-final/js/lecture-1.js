//FN ES6
const first = ()=>{
    console.log('1st Function is Here');
    second();
    third();
    final();
}
const second = ()=>{
    console.log('2nd Function is Here');
}
const third = ()=>{
    //console.log('3st Function is Here');
    setTimeout(()=>{
        console.log('3rd Function is Here');
    },3000);
}
const final = ()=>{
    console.log('4th Final Function is Here');
}
first();

//1st
//2nd
//3rd
//4th
