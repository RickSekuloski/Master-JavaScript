console.log('lecture 2, Call Backs');

function getMovie(){

    setTimeout(()=>{
        const movieID = [1000,1001,1002,1003,1004];
        console.log(movieID);
        setTimeout((id)=>{
            const movie = {
                title : 'The Old Guard',
                score : 6.5,
                rottenTomatoes : '81%',
                actor : 'Charlize Theron',
                releaseYear : 2020
            }
            console.log(`${id} , ${movie.title}, IMDB:${movie.score}, year:${movie.releaseYear}, rottenTomatoes:${movie.rottenTomatoes}, actor: ${movie.actor}`);
            setTimeout((year)=>{
                const movie1 = {
                    title : 'Angel Has Fallen',
                    score : 6.5,
                    rottenTomatoes : '39%',
                    actor : 'Gerald Butler',
                    releaseYear : 2020
                }
                console.log(`This movie was released in the same year of ${year},
                 ${movie1.title}, IMDB:${movie1.score}, year:${movie1.releaseYear}, rottenTomatoes:${movie1.rottenTomatoes}, actor: ${movie1.actor}`);
            },1000,movie.releaseYear);
        
        },2000,movieID[4]);
        
    },2500);
}
getMovie();