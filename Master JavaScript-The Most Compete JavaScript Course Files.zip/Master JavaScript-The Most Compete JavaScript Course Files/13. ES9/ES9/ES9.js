/* ES8 Features 
1.Object Spread Operator
*/

const cars = {
    bmw:15,
    tesla:40,
    ram:15,
    ford:45
}

const {bmw, ...rest} = cars;

// let array = [1,2,3,4,5];

// function avgArray (a,b,c,d,e){
//     return (a+b+c+d+e)/array.length;
// }
// avgArray(...array);

function objSpread(name1,name2){
    console.log(name1);
    console.log(name2);
}
objSpread(bmw,rest);

