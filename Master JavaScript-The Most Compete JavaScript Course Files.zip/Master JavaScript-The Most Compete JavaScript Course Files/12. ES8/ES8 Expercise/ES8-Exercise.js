// ES8 Exercises Solve the below problems:

/* #1) Line up the Slug and the Rabbit at the starting point:*/
const startingPoint = '    🎬';//Start Point
let snail = '🐌';
let rabbit = '🐇';

/* The End Result it should look like this: */
'    🎬'
'    🐌'
'    🐇'

// when you do:
console.log(startingPoint);
console.log(snail);
console.log(rabbit);


/* #2) What happens when you run snail.trim().padEnd(6, '=') on the snail variable
Read about what the second parameter does in padEnd and padStart */
snail = snail.trim().padEnd(6, '=');


// #3) Get the below object to go from:
let obj = {
  My: 'real',
  name: 'is',
  Riste: 'Sekuloski'
}
// to this:
'My real name is Riste Sekuloski'
