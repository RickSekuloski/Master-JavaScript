//DECLARING A VARIABLE USING LET AND CONST

//ES5
var personNameES5 = 'Will Smith';
var personAgeES5 = 55;
console.log('ES5 Syntax: '+ personNameES5 + ', age '+personAgeES5);

//MUTATE THE VALUES OF THE VARIABLES
personNameES5 = 'Will Smith Junior';
personAgeES5 = 59;
console.log('ES5 Mutated : '+ personNameES5 + ', age '+personAgeES5);

console.log('ES6 Bellow');
//ES6
// const personNameES6; //Uncaught SyntaxError: Missing initializer in const declaration
const personNameES6 = 'Tom Cruise';
let personAgeES6;
personAgeES6 = 55;
console.log('ES6 Syntax : '+ personNameES6 + ', age '+personAgeES6);
personAgeES6 = 56;
console.log('ES6 Syntax : '+ personNameES6 + ', age '+personAgeES6);

//BLOCKED VS FUNCTION SCOPE

//ES5 VARIABLES ARE FUNCTION SCOPED
function marriedStatus(personStatus){
    if(personStatus){
        var husbandName = 'Tom';
        var wifeName = 'Maria';
        var yearOfMarriage = 2020;
       // console.log(husbandName + ' is happily married with '+ wifeName + ', in the year '+ yearOfMarriage);
    }
    console.log(husbandName + ' is happily married with '+ wifeName + ', in the year '+ yearOfMarriage);
};
//ES5 IS FUNCTION SCOPED SO OUTSIDE VARIABLES CANNOT BE CALLED
//console.log(husbandName + ' is happily married with '+ wifeName + ', in the year '+ yearOfMarriage);
marriedStatus(true);

//ES6 VARIABLES ARE BLOCK SCOPED
function marriedStatusES6(personStatus){
    console.log(husbandName);
    let husbandName,wifeName, yearOfMarriage;
    const lastName = 'Smith';
    if(personStatus){
        husbandName='Will';
        wifeName= 'Jada';
        yearOfMarriage = 1987;
        console.log(husbandName + ' is happily married with '+ wifeName + ' '+lastName+', in the year '+ yearOfMarriage);
    }
    //ES6 ARE BLOCKED SCOPED, MEANING THE LIVE INSIDE THE BLOCK THEY ARE DEFINED
    //NO ACCESS OUTSIDE THEIR BLOCK SCOPE
  console.log(husbandName + ' is happily married with '+ wifeName + ' '+lastName+', in the year '+ yearOfMarriage);
};
marriedStatusES6(true);