//Template literals (Template strings)
console.log('Template literals (Template strings)');
//ES5
var firstName = 'Lionel';
var lastName = 'Messi';
var occupation ='Football Player';
var barcelonaDebut = 2003;
var today = new Date();
var currentYear = today.getFullYear();

function calcYearOfPlay(year){
    return currentYear - year;
}

//ES5 String OUTPUT
console.log(firstName + ' ' + lastName + ' is a FC Barcelona player since he was a small boy.\n' +
'His debut was '+calcYearOfPlay(barcelonaDebut)+ ' years ago. And he will probably finish its career there.');
//ES6 STRING LITERALS
console.log(`${firstName} ${lastName} is a FC Barcelona player since he was a small boy
His debut was ${calcYearOfPlay(barcelonaDebut)} years ago. And he will probably finish its career there.`);



//Lionel Messi
//NEW ES6 STRING METHODS
let result;
const nameString = `${firstName} ${lastName}`;
//1.STARTSWITH, RETURN TRUE/FALSE 
result = nameString.startsWith('L');//true
result = nameString.startsWith('M');//false
result = nameString.startsWith('l');//false

//2.ENDSWITH, RETURN TRUE/FALSE 
result = nameString.endsWith('i');//true
result = nameString.startsWith('I');//false

//3.REPEAT , RETURN THE STRING AS MANY TIMES WE WANT 
result = nameString.repeat(3);//true
result = `${nameString} `.repeat(3);//true
result = `${nameString} 
`.repeat(5);//true
console.log(result);