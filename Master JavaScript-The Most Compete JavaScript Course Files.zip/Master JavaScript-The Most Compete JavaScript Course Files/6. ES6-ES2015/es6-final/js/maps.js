//MAPS, NEW DATA STRUCTURE WITH KEY/VALUES

//ES6 MAPS

//declare a map
const poll = new Map();

//set entries to a map using set keyword and then key/value pair
poll.set('poll','Are you happy with this JS course so far?');
poll.set(true,'YES');
poll.set(false,'NO');
poll.set(4,'Uncertain');
poll.set(5,'Un decided');
poll.set(6,'Other');
//console log the entire map
console.log(poll);

//retrieve the entry from a map using keyword get
console.log(poll.get('poll'));

//size of a map
console.log(poll.size);

//delete an entry
//poll.delete(false);

//check before delete

if(poll.has(false)){
   // poll.delete(false);
}
else{
    console.log('This entry is no longer in the list');
}
//clear the entire map
//poll.clear();

//console log the entire map
console.log(poll);


//looping and iteration
console.log('======================= looping through maps using forEach ====================');

poll.forEach((value,key) => (console.log(`${key}, ${value}`)));
//looping and iteration
console.log('======================= looping through maps using for of ====================');

for(const key of poll){
    console.log(key);
}

console.log('======================= looping through maps using for of with keys and values ====================');

for(const [key,value] of poll.entries()){
    console.log(`${key}, ${value}`);
}

console.log('======================= looping through maps using for of and extract values that have number as key ====================');

for(const [key,value] of poll.entries()){
   if(typeof(key)==='number'){
     console.log(`${key}, ${value}`);
   }
}