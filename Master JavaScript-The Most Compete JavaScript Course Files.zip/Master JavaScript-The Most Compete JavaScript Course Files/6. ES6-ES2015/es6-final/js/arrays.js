//ARRAYS FOR OF, FINDINDEX , FIND, ARRAY.FROM
//CONTINUE AND BREAK STATEMENTS

//ES5
var red,yellow,green, es5Container,lightContainer;
red ='.es6-container__trafficlight--red';
green ='.es6-container__trafficlight--green';
yellow ='.es6-container__trafficlight--yellow';
es5Container = document.querySelectorAll(red+','+ yellow+','+green);

//convert the nodelist into array ES5
lightContainer = Array.prototype.slice.call(es5Container);
// console.log(es5Container);
// console.log(lightContainer);

//ES6 Using Array.from, this will take the nodelist and convert into an array
let es6Container = Array.from(es5Container);
console.log(es6Container);

//FOR OF

for(const element of es6Container){
    
    if(element.className ==='es6-container__trafficlight--red'){
        // console.log('we found red');
       
        element.style.backgroundColor = 'black';
        break;
    }
    else{
        
        // console.log('we will loop two more times');
    }
}

const scores = [15,50,80,77,8,47,97];
//FINDINDEX
let result = scores.findIndex(current => current >=95);
console.log(result);

//FIND
let findValue = scores.find(current => current >=95);
console.log(findValue);