/*SUBCLASSES AND INHERITANCE

1 PARENT CLASS WITH ITS OWN ATTRIBUTES AND METHODS
2.CHILD CLASS OR SUBCLASS HAVE ITS OWN METHODS AND ATTRIBUTES
3.THE CHILD WILL NOW BE ABLE TO GET THE METHODS AND ATTRIBUTES FROM ITS PARENT

*/
//ES5 SUPERCLASS
function PersonES5(firstName,lastName,age,nationality){
    this.firstName = firstName;
    this.lastName = lastName;
    this.age = age;
    this.nationality = nationality;
}
//METHOD
PersonES5.prototype.calculateBirthYear = function(){
    var currentYear = new Date().getFullYear();
    var yearBorn = currentYear - this.age;
    console.log(yearBorn);
}
//SUBCLASS
function ActorES5(firstName,lastName,age,nationality,occupation,interests,movies,oscars){

    PersonES5.call(this,firstName,lastName,age,nationality);
    //SET THE ARGUMENTS FROM ACTOR SUBCLASS
    this.occupation = occupation;
    this.interests =  interests;
    this.movies = movies;
    this.oscars = oscars;
}

//PROTOTYPE PROPERTY OF ACTOR AND PERSON
ActorES5.prototype  = Object.create(PersonES5.prototype);

var markActorES5 = new ActorES5('Mark','Wahlberg',49,'American','Actor','Action Movies','Spenser Confidential',0);
var markDob = markActorES5.calculateBirthYear();

//ES6 CLASS - SUBCLASS

class PersonES6{
    //constructor
    constructor(firstName,lastName,age,nationality){
       this.firstName = firstName;
       this.lastName = lastName;
       this.age = age;
       this.nationality = nationality;
    }
    //methods
    calculateBirthYear(){
       var currentYear = new Date().getFullYear();
       var yearBorn = currentYear - this.age;
       console.log(yearBorn);
    }

}

//ACTOR SUBCLASS
class ActorES6 extends PersonES6{
    constructor(firstName,lastName,age,nationality,occupation,interests,movies,oscars){
        //Super method that will the PersonES6
        super(firstName,lastName,age,nationality);
        //SET THE ARGUMENTS FROM ACTOR SUBCLASS
        this.occupation = occupation;
        this.interests =  interests;
        this.movies = movies;
        this.oscars = oscars;
     }

     oscarsWon(){
         console.log(this.oscars);
     }
}
console.log('ES6 Subclasses');
let markActorES6 = new ActorES6('Mark','Wahlberg',49,'American','Actor','Action Movies','Spenser Confidential',10);
markActorES6.calculateBirthYear();
markActorES6.oscarsWon();