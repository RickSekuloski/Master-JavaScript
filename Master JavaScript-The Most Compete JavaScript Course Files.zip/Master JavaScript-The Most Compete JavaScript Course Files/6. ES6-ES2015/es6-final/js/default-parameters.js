//DEFAULT PARAMETERS

//ES5

function InternationalVisitors(firstName,lastName,dob,nationality,visaType,entryDate,expiryDate){

    // if(visaType === undefined){
    //     visaType = 'Visitor';
    // }
    // if(entryDate === undefined){
    //     entryDate = new Date();
    // }
    // if(expiryDate === undefined){
    //     today = new Date();
    //     var year = today.getFullYear()+1;
    //     expiryDate = year;
    // }
    today = new Date();
    var year = today.getFullYear()+1;

    visaType === undefined ? visaType ='Visitor' : visaType = visaType;
    entryDate === undefined ? entryDate = today : entryDate = entryDate;
    expiryDate === undefined ? expiryDate = year : expiryDate = expiryDate;


    this.firstName = firstName;
    this.lastName = lastName;
    this.dob = dob;
    this.nationality = nationality;
    this.visaType = visaType;
    this.entryDate = entryDate;
    this.expiryDate = expiryDate;
}

var andy = new InternationalVisitors('Andy','Murray',1980,'English','Student');
console.log(andy);

//ES6 Default parameters

today = new Date();
var year = today.getFullYear()+2;
function InternationalVisitorsES6(firstName,lastName,dob=1950,nationality='American',visaType='Visitor',entryDate=today,expiryDate=year){

    this.firstName = firstName;
    this.lastName = lastName;
    this.dob = dob;
    this.nationality = nationality;
    this.visaType = visaType;
    this.entryDate = entryDate;
    this.expiryDate = expiryDate;
}

var tom = new InternationalVisitorsES6('Tom','Cruise',1965, 'English','Student');
console.log(tom);