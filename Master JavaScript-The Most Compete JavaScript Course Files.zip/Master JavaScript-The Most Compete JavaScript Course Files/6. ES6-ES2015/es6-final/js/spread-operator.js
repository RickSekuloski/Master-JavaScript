//SPREAD OPERATOR

const classA = ['Andy','Mark','Sara','Tom'];
const classB = ['Sonia','Chuck','Dean','Jessie'];

//const aB = [...classA,...classB];
const aB = ['Morgan',...classA,'Theodore',...classB,'Sam'];
//console.log(aB);

//Spread operator ES6 with nodeList
let nodeList1 = document.querySelectorAll('.es6-container__trafficlight--red'+ ','+'.es6-container__trafficlight--yellow');

let nodeList2 = document.querySelectorAll('.title'+ ','+'.es6-container__trafficlight--green'+','+'.brackets');

const nodeList3 = [...nodeList1,...nodeList2];

let classNames = [];
nodeList3.map(function(current,i){
    classNames[i] = current.className;
});
console.log(nodeList3);
console.log(classNames);
