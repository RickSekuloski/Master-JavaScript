//BLOCKS AND IIFES
console.log('Blocks and IIFEs');

//ES5 DATA PRIVACY WITH IIFES FN
var ES5Fn = (function() {
    var a = 5;
    return{
        result:function () {
            var b = 95;
            return a + b;
        }
    };
})();

var result = ES5Fn.result();
console.log(result);
//THIS IS NOT WORKING BECAUSE WE CANNOT ACCESS FN AND VARIABLES THAT ARE PRIVATE
//console.log(a);
{
    const myName ='Rick';
    let age = 33;
    //var lastName = 'Smith';
    console.log(myName + ' ' + age);
}
//THIS WILL WORK BECAUSE ES5 VARIABLES ARE FN SCOPED
//console.log(lastName);
//BLOCK SCOPE ACCESS
//console.log(myName + ' ' + age);