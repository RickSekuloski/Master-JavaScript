//CLASSES IN JAVASCRIPT

//ES5 FN CONSTRUCTOR
function PersonES5(firstName,lastName,age,nationality){
    this.firstName = firstName;
    this.lastName = lastName;
    this.age = age;
    this.nationality = nationality;
}
//METHOD
PersonES5.prototype.calculateBirthYear = function(){
    var currentYear = new Date().getFullYear();
    var yearBorn = currentYear - this.age;
    console.log(yearBorn);
}
//INSTANTIATE THE PERSON FN CONSTRUCTOR
 var andy = new PersonES5('Andy','Garcia',64,'American').calculateBirthYear();
 var mark = new PersonES5('Mark','W',45,'American').calculateBirthYear();

 //ES6 CLASSES

 class PersonES6{
     //constructor
     constructor(firstName,lastName,age,nationality){
        this.firstName = firstName;
        this.lastName = lastName;
        this.age = age;
        this.nationality = nationality;
     }
     //methods
     calculateBirthYear(){
        var currentYear = new Date().getFullYear();
        var yearBorn = currentYear - this.age;
        console.log(yearBorn);
     }

     //static methods
     static printSomething(){
         console.log('This is static method inside a class and it will not be shared by the class instances');
     }
     
 }
console.log('ES6 Classes');
 let morgan = new PersonES6('Morgan','Freemen',83,'American');
 morgan.calculateBirthYear();
//Static classes cannot be used by the class instances
 // morgan.printSomething();
 //call of the static method
 PersonES6.printSomething();