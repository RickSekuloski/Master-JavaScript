//LECTURE:ARROW FUNCTION
console.log('Arrow Function');

const scores = [15,55,92,77,46];
//ES5
console.log('ES5 Result');
var mathScoresES5 = scores.map(function(curr,index,arr){
    return 100 - curr;
});
console.log(mathScoresES5);

//ES6 ARROW FN WITH ONE ARGUMENT AND ONE LINE OF CODE
console.log('ES6 Result');
const mathScoresES6 = scores.map(curr => 100 -curr);
console.log(mathScoresES6);
//ES6 ARROW FN WITH TWO ARGUMENTS AND ONE LINE OF CODE
const mathScores1ES6 = scores.map((current,index) => `Index ${index}: ${100-current}`);
console.log(mathScores1ES6);

//ES6 ARROW FN WITH TWO ARGUMENTS AND MULTIPLE LINES OF CODE

const multiES6 = scores.map((current,index) => {
    const months = {
        0:'January',
        1:'February',
        2:'March',
        3:'April',
        4:'May',
        5:'June',
        6:'July',
        7:'August',
        8:'September',
        9:'October',
        10:'November',
        11:'December'
    };
    const days = {
        0:'Sun',
        1:'Mon',
        2:'Tue',
        3:'Wed',
        4:'Thu',
        5:'Fri',
        6:'Sat'
    };
    const today = new Date();
    const year = today.getFullYear();
    const date = today.getDate();
    const dayName = days[today.getDay()];
    const monthName = months[today.getMonth()];
    const formattedDate = `${dayName}, ${date} ${monthName} ${year}`;
    return `Test taken on:${formattedDate}, Student ID ${index}: Scored ${100-current}`;
});

console.log(multiES6);