//REST PARAMETERS

function myScore(...scores){
    //console.log(scores);
    scores.forEach(curr => console.log(100-curr));
}
//myScore(15,25,88,65,77,39);

//rest parameters with additional argument
function myScore1(maxScore,...scores){
// console.log(scores);
    scores.forEach(curr => console.log(maxScore-curr));
}
myScore1(100,15,25,88,65,77,39);