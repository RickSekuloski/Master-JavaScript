console.log('ARROW FN AND LEXICAL THIS KEYWORD');

var red,green,yellow,desc;
red = '.es6-container__trafficlight--red';
green ='.es6-container__trafficlight--green';
yellow ='.es6-container__trafficlight--yellow';

//ES5
var trafficLightES5 = {
    color:'Red',
    meaning:'Stop',
    priority:1,
    signalMeaning:function(){
     
        var thisKeyword = this;
        document.querySelector(red).addEventListener('click',function(){
            desc = 'You Have Clicked On The '+ thisKeyword.color +
            ', and this means you need to '+thisKeyword.meaning +
            '. The priority of this traffic light is '+ thisKeyword.priority;
            console.log(desc);
        });
    }
}
// trafficLightES5.signalMeaning();

//ES5 Second Way to Access This Keyword
var trafficLight1ES5 = {
    color:'Red',
    meaning:'Stop',
    priority:1,
    signalMeaning:function(){

        document.querySelector(red).addEventListener('click',function(){
            desc = 'You Have Clicked On The '+ this.color +
            ', and this means you need to '+this.meaning +
            '. The priority of this traffic light is '+ this.priority;
            console.log(desc);
        }.bind(this));
    }
}
trafficLight1ES5.signalMeaning();


//ES6 Second Way to Access This Keyword
const trafficLightES6 = {
    color:'Green',
    meaning:'Go',
    priority:3,
    signalMeaning:function(){
        document.querySelector(green).addEventListener('click',() =>{
            desc =`You Have Clicked On The ${this.color },and this means you need to ${this.meaning}. The priority of this traffic light is ${this.priority}`;
            console.log(desc);
        });
    }
}
trafficLightES6.signalMeaning();


//ES5
function Student(name,id){
    this.name = name;
    this.id = id;
}

var scores = [55,66,77,87];

Student.prototype.studentScores = function(scores){
    var thisKeyword = this;
var studentScoresArr = scores.map(function(current){
    return thisKeyword.name + ' with student id: ' +thisKeyword.id + ' scored in the test '+current;
});
console.log(studentScoresArr);
};

var Andy = new Student('Andy',4034).studentScores(scores);


//ES6 Lexical This Keyword
function StudentES6(name,id){
    this.name = name;
    this.id = id;
}

let scoresES6 = [66,78,44,88];

StudentES6.prototype.studentScores = function(scoresES6){

let studentScoresArr = scoresES6.map((current)=> `${this.name}  with student id:${this.id}  scored in the test ${current}`);
console.log(studentScoresArr);
};

var Tom = new StudentES6('Tom',5877).studentScores(scoresES6);