
//DESTRUCTURING LECTURE
//ARRAY
const personArr = ['Tommy',55,1965,'USA'];

const [name,age,dob,country] = personArr;
let desc = `${name}, ${age}, ${dob}, ${country}`;
console.log(desc);

//OBJ
const personObj ={
    personName:'Rick',
    personAge:33,
    personDob:1987,
    personCountry:'Australia'
}

const {personName:n,personAge:a,personDob:d,personCountry:c} = personObj;
// desc = `${personName}, ${personAge}, ${personDob}, ${personCountry}`;
desc = `${n}, ${a}, ${d}, ${c}`;
console.log(desc);
//Return multiple variables from a fn with DESTRUCTURING

function multiReturn(name,lastName,occupation){
    return [name,lastName,occupation];
}

const [name1,lastName,occupation] = multiReturn('Andy','Tom','Actor');
console.log(name1);
console.log(lastName);
console.log(occupation);
