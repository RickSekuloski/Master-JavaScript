//primitive they hold the value inside the variable
var numOne = 5;
var numTwo = numOne;


numOne = 12;
console.log(numOne);
console.log(numTwo);

//objects they hold the reference of the value/object
console.log('Objects');
var firstObj ={
    name :'Rick',
    lastName : 'Sekuloski',
    courses : 3
}

var secondObj = firstObj;

firstObj.courses = 12;

console.log(firstObj.courses);
console.log(secondObj.courses);


//Functions
function tryMutate(numOne,firstObj){
    var result = 0;
    numOne = 4;
    firstObj.courses = 24;
    return result = numOne;
}

var result = tryMutate(numOne,firstObj);

console.log('Function');
console.log(result);
console.log(numOne);
console.log(firstObj.courses);
console.log(secondObj.courses);
