//loops and iterations, for and while loops

//1 Three parts in for lopp
// for(1,2,3){

// }
//1. We Initial a value and we define
//2.Condition, here the condition must be true
//3.Counter and we increment that value
console.log('Looping all numbers with for loop.');
//i++
// i = 0
// i = i+1 
for(var i = 0; i < 10; i++){
    //block of code
    console.log(i);
}
//The Flow
/*
 1. i = 0, 0 < 10 => true, console.log(0), increase i by one or i++ => i=1
 1. i = 1, 1 < 10 => true, console.log(1), increase i by one or i++ => i=2
 1. i = 3, 3 < 10 => true, console.log(3), increase i by one or i++ => i=3
 .
 .
 .
 .
 .
 9. i = 9, 9 < 10 => true, console.log(9), increase i by one or i++ => i=10
 10. i = 10, 10 < 10 => false, break
 */


console.log('Looping all numbers with for loop including the number 10.');
 
for(var j = 0; j <= 10; j++){
    //block of code
    console.log(j);
}

console.log('Looping all odd numbers.');
//1 , 3 , 5 ,7 ,9
//  i+=2 => i = i + 2
for(var i = 1; i <= 10; i+=2){
    //block of code
    console.log(i);
}
console.log('Looping all even numbers.');
//0 ,2 ,4,6 ,8,10
//  i+=2 => i = i + 2
for(var i = 0; i <= 10; i+=2){
    //block of code
    console.log(i);
}

console.log('Reverse For Loop Iteration.');

for(var i = 10; i >= 0; i--){
    //block of code
    console.log(i);
}
console.log('Reverse For Loop Iteration Without 0.');

for(var i = 10; i > 0; i--){
    //block of code
    console.log(i);
}

//Array and For Loop

var citiesArray =[
    'Melbourne',
    'Brisbane',
    'Sydney',
    'Perth',
    'Darwin',
    'Hobart',
    'Newcastle'
];
console.log('Print All of the Cities In Australia.');
var sizeOfCities = citiesArray.length;
for(var i = 0; i < sizeOfCities; i++){
    //block of code
    console.log(citiesArray[i]);
}


//With Population
var citiesArray =[
    'Melbourne',
    'Brisbane',
    'Sydney',
    'Perth',
    'Darwin',
    'Hobart',
    'Newcastle',
    24
];
console.log('Print All of the Cities In Australia without population.');
var sizeOfCities = citiesArray.length;
for(var i = 0; i < sizeOfCities; i++){
    //block of code
    
    if(typeof citiesArray[i]==='string'){
        console.log(citiesArray[i]);
    }
    // 
}
//continue and break
var citiesArray =[
    'Melbourne',
    'Brisbane',
    'Sydney',
    6,
    'Perth',
    'Darwin',
    'Hobart',
    'Newcastle',
    24
];
console.log('Print All of the Cities In Australia without population with continue.');
var sizeOfCities = citiesArray.length;
for(var i = 0; i < sizeOfCities; i++){
    //block of code
    
    if(typeof citiesArray[i] !== 'string') continue;
        console.log(citiesArray[i]);
   
    // 
}

// break
var citiesArray =[
    'Melbourne',
    'Brisbane',
    'Sydney',
    6,
    'Perth',
    'Darwin',
    'Hobart',
    'Newcastle',
    24
];
console.log('Print All of the Cities In Australia without population with break.');
var sizeOfCities = citiesArray.length;
for(var i = 0; i < sizeOfCities; i++){
    //block of code
    
    if(typeof citiesArray[i] !== 'string') break;
        console.log(citiesArray[i]);
   
    // 
}

//While Loop
var i = 0;
console.log('While Loop.');

while(i<=10){
    console.log(i);
    i++;
}

//While Loop
var i = 10;
console.log('Reverse While Loop.');

while(i >= 0){
    console.log(i);
    i--;
}