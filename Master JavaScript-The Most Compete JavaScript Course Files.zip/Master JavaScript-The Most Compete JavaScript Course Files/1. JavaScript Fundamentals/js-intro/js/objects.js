//defining an object with key value pairs
//firstName is the key and the value is the Rick
var person = {
    firstName: 'Rick',
    lastName: 'Sekuloski',
    occupation :'Developer',
    dob :1987,
    related:['Maria','Theodore']
};
console.log(person);
//First Way - Accessing the properties of an object with dot notation
console.log('1. Accessing the properties of an object with dot notation');
console.log(person.firstName);
console.log('2. Accessing the properties of an object with  brackets');
console.log(person['lastName']);

//Object Data  Mutation and assigning new values
console.log('Data Mutation for his dob, change to 1999');
person.dob = 1999;
console.log(person);

//How to create an empty object
var carObject = new Object();
carObject.name = 'Ford';
carObject.type = 'Suv';
carObject['engine'] = 'V8';
console.log('Creating new Object');
console.log(carObject);