

// var numbers = [5, 3, 6, 7, 5, 3];
var numbers = [0,0];
function sum (numbers) {
    var sum = 0;
    for (var i = 0; i < numbers.length; i++){
        sum += numbers[i];
    }
    return sum;
  }
//console.log the sum
  if(sum !==0){
    console.log('Sum of an array is: '+ sum(numbers));
  }
  else{
      console.log('Sum is zero');
  }
  
  function average () {
      var length = numbers.length;
    var total = sum(numbers);
    var average=0;
    
        average = total/length;
        return average;
   
    
  }
  //console.log the average
  if(average !==0){
    console.log('Average of an array is: '+ average());
  }
  else{
    console.log('Average is 0');
  }
