// var stringArray = ['Rick','Theodore','Coding'];

//1 declaration of an array
var stringArray = [
    'Rick',
    'Theodore',
    'Coding'
];
console.log(stringArray);

//2nd way of declaration of an array
var stringCities = new Array(
    'Melbourne',
    'London',
    'New York'
);


console.log(stringCities);
//print out a single element
console.log(stringCities[0]);
var sizeOfCities = stringCities.length;
console.log(sizeOfCities);

//add new element
//stringCities[4]='Dubai';//this will create an array with empty slot
//add an element on the last position
stringCities[sizeOfCities] ='Dubai';
console.log(stringCities);

//array with different data types

var mixedArray = ['Rick',1987];
console.log(mixedArray);
//push method for adding an element on the last position
mixedArray.push('Sekuloski');
console.log(mixedArray);
//take an element from the last position
mixedArray.pop();
console.log(mixedArray);
//add an element to the first array position
mixedArray.unshift('Instructor');
console.log(mixedArray);

//remove an element from the first array position
mixedArray.shift();
console.log(mixedArray);

//push new elements
mixedArray.push('Sekuloski');
mixedArray.push('Great');
mixedArray.push('Course');
console.log(mixedArray);
var position = mixedArray.indexOf('Great');
console.log(position);
var find = prompt('Find me an element in the Array');

if(mixedArray.indexOf(find) === -1){
    console.log('No element is found');
}
else{
    console.log('Ok, we found the element '+ find + 
    ' On its ' +mixedArray.indexOf(find) + ' position');
}
