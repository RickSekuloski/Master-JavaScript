var date = new Date();
var currentYear = date.getFullYear();
// var currentYear = 2020;
console.log('This year is : '+currentYear);

var result,nextYear,infoFuture,dob, three;
dob = 1987;

//math operator minus

result = currentYear - dob;
console.log("I'm : " +result);

//math operator plus
nextYear = 1;

result = currentYear + nextYear;
console.log('Next year it will be: '+ result);


//math operator times
three = 3;

result = currentYear * 3;
console.log('Multiplication: '+ result);

//math operator devision
three = 3;

result = currentYear / 3;
console.log('Multiplication: '+ result);


/*Logical Operators > , <*/

var first, second, isBigger, isSmaller,name;
first = 10;
second = 5;
name='Rick';
isBigger = first > second;
isSmaller = first < second;

console.log('IsBigger: '+ isBigger);
console.log('isSmaller: '+ isSmaller);

//typeof operators
console.log(typeof first);
console.log(typeof name);
console.log(typeof isSmaller);

// var firstNumber, secondNumber;

// firstNumber = prompt('Enter the first number?');
// secondNumber = prompt('Enter the second number?');
// result = parseInt(firstNumber) + parseInt(secondNumber);
var firstName, lastName;
firstName = prompt('Enter your name?');
 lastName = prompt('Enter the last name?');
 result = firstName + ' '+ lastName;
console.log(result);