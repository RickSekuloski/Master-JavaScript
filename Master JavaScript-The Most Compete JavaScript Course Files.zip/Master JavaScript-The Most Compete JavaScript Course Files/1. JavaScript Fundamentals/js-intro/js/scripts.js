//External js call
console.log('Hello World From External File scripts Js File!');