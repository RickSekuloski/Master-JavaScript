

// Rick  - Web Developer
// Andy  - Programmer
// Maria  - Nurse
// Sam  - Teacher
// Dean  - Baker


var person = prompt('Just Provide Name so we can check the occupation');
switch(person){
    case 'Rick':
        console.log('Rick is a web developer');
        break;
    case 'Andy':
        console.log('Andy is a programmer');
        break;
    case 'Maria':
        console.log('Maria is a nurse');
        break;
    case 'Sam':
        console.log('Sam is a teacher');
        break;
    case 'Dean':
        console.log('Dean is a baker');
        break;

    default:
        console.log('We dont have details for this person');
        
}