//if else

// var isWorking,workPosition,name;
// name='Rick';
// workPosition = 'Web Developer';
// isWorking = 'working';

// if(isWorking ==='no'){
//     console.log('Rick Not Working');
// }
// else{
//     console.log('1. Yes '+ name + ' is working in this position ' + workPosition);
// }

// isWorking = false;


// if(isWorking){
//     console.log('2. Yes '+ name + ' is working in this position ' + workPosition);
// }
// else{
//     console.log('Rick Not Working');
// }

//if else if
//logical operators and && , or || ! 
var weight = 72;

if(weight <= 50){
    console.log('Ok you are very slim!');
}
else if(weight >= 60 && weight <= 70){
    console.log('Ok you need to watch out, take care of your health!');
}
else if(weight >= 70 && weight <= 80){
    console.log('Ok you need to start exercising!');
}
else{
    console.log('Ok you need to go on diet!');
}

var first, second;
first = false;
second = true;

if(first || second){
    console.log('Yes One or Two of the conditions are true');
}

if(!first){
    console.log('It inverts true/false values');
}
