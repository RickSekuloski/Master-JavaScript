//Ternary operator

var name='Rick';
var salary = 2499;
//less than 500 per month you are not employed
//greater than 2500 per month you are considered as employed

salary >=2500 ? console.log(name + ' Is employed and he is getting :' + salary) : console.log(name + ' is not employed and he is getting ' +salary );

//same case with if statement 
if(salary>=2500){
    console.log('Rick is employed person now and he is getting '+ salary);
}
else
{
    console.log('Rick is not employed person now and he is getting '+ salary);
}

