

//call this function
//1 how to print the output from the function
function returnString1(){

    return "Here we will return a string without console log";
   
}
console.log(returnString1());

//2 now we will make the output without return
function returnString2(){

    console.log("Here we will return a string without return, just with console log");
   
}
 returnString2();

//3 the output we will catch it in a variable

function returnString3(){

    return "Here we will return a string and store the output in a variable";
   
}
var result = returnString3();
console.log(result);

// Area of Rectangle A = L * W , in cm

var length, width, area;

function areaRectangle(length, width){

    return area = length*width;
}
var result = areaRectangle(5,4);
console.log("The area of the rectangle is :" + result);


//new function for calculating the area in inch
function areaToInches(length, width){
    if(length > 0 && width > 0){
        var result = areaRectangle(length,width);
        var resultInch = result * 0.393701;
        console.log("The result for the rectangle in inc :"+resultInch);
    }
    else{
        console.log("Zero or negative values are not accepted");
    }
   
}
areaToInches(5,4);

// function expression

//checking in what generation person belongs
var generation = function(age,name){

    if(age < 18){
        return "This person with name: " + name + " belongs to Generation Z iGeneration";
    }
    else if(age >= 18 && age < 34){
        return "This person with name: " + name + " belongs to Millennials  Generation Y";
    }
    else if(age > 34 && age <= 50){
        return "This person with name: " + name + " belongs to Generation X";
    }
    else{
        return "This person with name: " + name + " belongs to Baby Boomers";
    }
        
}
console.log(generation(16,'Amanda'));
console.log(generation(35,'Chuck'));
console.log(generation(55,'John'));

