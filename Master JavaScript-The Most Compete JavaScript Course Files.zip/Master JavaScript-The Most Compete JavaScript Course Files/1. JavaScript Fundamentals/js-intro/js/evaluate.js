//truthy values: NOT , falsy values
//falsy values : undefined, null, '', NaN, 0



var age = '';
// var age = 33;
//var age = 0;
//var age;
if(age || age === '' || age === 0){
    console.log('The age variable is defined');
}
else{
    console.log('The age variable is not defined');
}

// if(age){
//     console.log('The age variable is defined');
// }
// else{
//     console.log('The age variable is not defined');
// }

// Equality operator '==' does / type coercion

age = 33;

if(age === '33'){

    console.log('This is true because of the type coercion');
}
else{
    console.log('This is not true with ===');
}