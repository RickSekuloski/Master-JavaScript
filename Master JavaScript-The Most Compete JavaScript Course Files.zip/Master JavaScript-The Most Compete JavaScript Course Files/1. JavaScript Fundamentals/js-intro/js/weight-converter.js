/*This Coding Assignment will test your ability to use simple maths operators
and what we have learned so far.
1. You will need to prompt the user for his weight in pounds
2. After you provide the weight in pounds and you will need
to convert it into kg. Then you need display the weight in console
3.Formula you need to use is: 1 pound is 0.45359237 kg
4. Then compare the kg to a weight of 60kg and based on that 
tell if the person should go on diet or not with true or false
*/


var pound,kg,unit,givenWeight,decision;

unit = 0.45359237;
givenWeight=60;

pound = prompt('Enter the your weight in pounds?');
kg = pound * unit;
console.log(kg);

decision = givenWeight < kg;

console.log('Based on the calculation should you go on diet ? '+ decision);


