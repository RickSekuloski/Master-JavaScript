var currentYear = 2020;
var dobRick = 1987;
var isTeenager = 16; //13-19

var checkStatus = currentYear - dobRick >= isTeenager;

// alert(checkStatus);
var firstNumber,secondNumber,thirdNumber,forth,result;
firstNumber = 15;
secondNumber = 5;
thirdNumber = 20;
forth = 5;
// result = (thirdNumber - firstNumber) / secondNumber;
// result = (thirdNumber - firstNumber) * secondNumber;
// alert(result);
result = (firstNumber+thirdNumber) * forth - secondNumber;
/*
(15+20)*5 - 5;
1* = 15+20 => 35
2* = 35*5 => 175
3* = 175 - 5 => 170
*/
alert(result);

