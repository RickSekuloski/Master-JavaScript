//(Primitive ) Variables and Data Types

/*
1. String
2. Number 
3. Boolean 
4. Undefined
5. Null
*/ 

var firstName = 'Peter';
var old = 33;
var alien = false;
var nonValue;
//variables naming convention, Can start with Letter, $ Or _ , but it cannot with numbers
var $money = 100;
var _lastName = 'Collins';
// var %sum = 500; //not valid naming convention


// console.log('Printing the value from the variable');
//alert(firstName);
// console.log(firstName);
// console.log(old);
// console.log(alien);
// console.log(nonValue);
// console.log($money);
// console.log(_lastName);


//Variable type coercion and mutation

console.log(firstName + ' ' + _lastName);

console.log(firstName + ' ' + _lastName + ' is : ' + old + ' years old!');

//declare variables in one line
var first, second, third, forth;
//assign a value in the lines bellow
first = 'Rick';
second = 'Andy';
third = 'John';
forth = 'Melisa';

console.log(first +' , ' + second);

second ='Novak';


console.log(first +' , ' + second);