export const key = '1c3a009c';
export const api = 'http://www.omdbapi.com/?';
export const movieUrl = 'https://www.imdb.com/title/';