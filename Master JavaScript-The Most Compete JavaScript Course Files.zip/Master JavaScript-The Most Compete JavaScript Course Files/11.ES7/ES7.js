/* ES7 - Exercises Solve the below problems:


/* #1) Check if this array includes the name "Andy".*/
const names = ['Tom', 'Marina', 'John', 'Andy'];

/* #2) Check if this array includes any name that has "Tom" inside of it. 
    If it does, return that name in a new array. 
    
    Challenge: A Key to solve is to use 
    use names.filter() to filter out the result */ 
const names = ['Thomas', 'Theodore', 'Tom', 'Tony'];


/* #3) Create a function that calculates the power of 100 of a
 number entered as a parameter*/


/* #4) Using your function from the exercise 3, as
a parameter inside that function put (10000).
 What is the result? Research for yourself why you get this result*/

